# GIS + Kakao Map + Pedestrian Signal — Extracted Modules

Extracted from the **Smombie Detector** Expo app. Contains everything for:

1. **Pedestrian Signal** (Seoul V2X live walk/wait signal)
2. **GIS Risk Factors** (crosswalk distance, streetlights, traffic, slope, risk boost)
3. **Live GIS Map** (Kakao Map via WebView on iOS/Android, web fallback)

---

## Folder structure

```
gis-kakao-extract/
├── components/
│   ├── SignalCard.tsx           # Live pedestrian signal UI
│   ├── GISInfoCard.tsx          # 4-factor risk panel + boost bar
│   ├── NativeMapView.native.tsx # Kakao map (iOS/Android, WebView + Leaflet fallback)
│   └── NativeMapView.tsx        # Web fallback (stats only)
├── context/
│   ├── GISContext.tsx           # GPS watcher + Overpass/Seoul GIS data provider
│   └── SignalContext.tsx        # Seoul V2X signal polling (depends on GISContext)
├── services/
│   └── signalAPI.ts             # Seoul V2X signal API client
├── utils/
│   └── seoulGIS.ts              # Seoul official crosswalk dataset helpers
├── hooks/
│   └── useColors.ts             # Color palette hook (light/dark)
└── constants/
    └── colors.ts                # Color tokens
```

All imports use the `@/` alias rooted at the project source folder
(e.g. `@/context/GISContext`). Set this in `tsconfig.json`:

```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": { "@/*": ["./*"] }
  }
}
```

---

## Required dependencies

Add to your Expo / React Native app's `package.json`:

```jsonc
{
  "dependencies": {
    "expo": "~54.0.0",
    "expo-location": "~19.0.8",
    "react": "*",
    "react-native": "*",
    "react-native-webview": "13.15.0",
    "react-native-safe-area-context": "~5.6.0",
    "@expo/vector-icons": "^15.0.3"
  }
}
```

`NativeMapView.tsx` (web fallback) also imports `react-native-safe-area-context`
and `@expo/vector-icons`. No `react-native-maps` required — Kakao Map is rendered
inside a WebView.

---

## App config (`app.json`)

```jsonc
{
  "expo": {
    "ios": {
      "infoPlist": {
        "NSLocationWhenInUseUsageDescription": "Used to check nearby crosswalks and pedestrian safety.",
        "NSAppTransportSecurity": {
          "NSExceptionDomains": {
            "kakao.com":          { "NSExceptionAllowsInsecureHTTPLoads": true, "NSIncludesSubdomains": true },
            "t-data.seoul.go.kr": { "NSExceptionAllowsInsecureHTTPLoads": true },
            "apis.data.go.kr":    { "NSExceptionAllowsInsecureHTTPLoads": true }
          }
        }
      }
    },
    "android": {
      "permissions": [
        "android.permission.ACCESS_FINE_LOCATION",
        "android.permission.ACCESS_COARSE_LOCATION"
      ]
    },
    "plugins": [
      ["expo-location", {
        "locationAlwaysAndWhenInUsePermission": "Used to check nearby crosswalks and pedestrian safety."
      }]
    ]
  }
}
```

---

## Provider hierarchy

`SignalContext` reads from `GISContext`, so the GIS provider must wrap it:

```tsx
import { GISProvider } from "@/context/GISContext";
import { SignalProvider } from "@/context/SignalContext";

export default function RootLayout() {
  return (
    <GISProvider>
      <SignalProvider>
        {/* your app */}
      </SignalProvider>
    </GISProvider>
  );
}
```

---

## Usage example

```tsx
import { useGIS } from "@/context/GISContext";
import { GISInfoCard } from "@/components/GISInfoCard";
import { SignalCard } from "@/components/SignalCard";
import NativeMapView from "@/components/NativeMapView";

function Screen() {
  const {
    nearestCrosswalkDist, streetlightCount, trafficLevel,
    slope, gisRiskBoost, dataSource, isLoading, error,
    refresh, hasPermission, requestPermission,
  } = useGIS();

  return (
    <>
      <SignalCard isMonitoring />
      <GISInfoCard
        nearestCrosswalkDist={nearestCrosswalkDist}
        streetlightCount={streetlightCount}
        trafficLevel={trafficLevel}
        slope={slope}
        gisRiskBoost={gisRiskBoost}
        dataSource={dataSource}
        isLoading={isLoading}
        error={error}
        onRefresh={refresh}
        hasPermission={hasPermission}
        onRequestPermission={requestPermission}
      />
      <NativeMapView />
    </>
  );
}
```

---

## Notes / configuration to review

- **Kakao JavaScript key** is hard-coded in `components/NativeMapView.native.tsx`
  (`KAKAO_JS_KEY`). Replace with your own key and register your bundle domain
  in the Kakao Developer Console → Platform → Web.
- **Seoul V2X & Seoul GIS** endpoints are public open-data APIs (no key required
  for the endpoints used here), but they are Seoul-region only. Outside Seoul,
  `GISContext` falls back to the OpenStreetMap Overpass API automatically.
- `SignalCard` only displays a signal when the user is within **50 m** of a
  crosswalk (`PROXIMITY_THRESHOLD_M` in `SignalContext.tsx`).
