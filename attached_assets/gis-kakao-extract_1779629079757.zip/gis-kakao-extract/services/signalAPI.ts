/**
 * signalAPI.ts — Seoul V2X Real-time Traffic Signal Service
 *
 * TWO ENDPOINTS (both confirmed working):
 *
 * 1. v2xSignalPhaseInformation — current phase per direction/type
 *    Returns: *StatNm fields  e.g. "protected-Movement-Allowed" | "stop-And-Remain" | null
 *
 * 2. v2xSignalPhaseTimingInformation — remaining time per direction/type
 *    Returns: *RmdrCs fields  e.g. 133.0 (divide by 10 → seconds)
 *
 * FIELD NAMING PATTERN:
 *   {direction}{type}StatNm / {direction}{type}RmdrCs
 *   Directions : nt (north) | et (east) | st (south) | wt (west)
 *   Types      : Bssg (basic) | Ltsg (left-turn) | Pdsg (pedestrian) | Stsg (straight)
 *
 * PEDESTRIAN FOCUS:
 *   We only care about the *PdsgStatNm and *PdsgRmdrCs fields.
 *   Phase: if any pedestrian direction is "protected-Movement-Allowed" → GREEN
 *          if all are "stop-And-Remain"                                → RED
 *   Time : pick the smallest non-null *PdsgRmdrCs ÷ 10 (seconds) when RED,
 *          or the largest non-null *PdsgRmdrCs ÷ 10 when GREEN (longest cross time).
 *
 * NOTE: Police crossroad API (getCrossRoadInfoList) returns 401 Unauthorized
 *       — coordinate matching is not used. Signals are shown without distance.
 */

const SEOUL_API_KEY =
  process.env.EXPO_PUBLIC_SEOUL_V2X_API_KEY ??
  "fc852b2e-4d4d-49c9-8b39-b806e977603f";

const BASE = "http://t-data.seoul.go.kr/apig/apiman-gateway/tapi";
const PHASE_URL  = `${BASE}/v2xSignalPhaseInformation/1.0?apikey=${SEOUL_API_KEY}`;
const TIMING_URL = `${BASE}/v2xSignalPhaseTimingInformation/1.0?apikey=${SEOUL_API_KEY}`;

// ─── Types ────────────────────────────────────────────────────────────────────

export type SignalPhase = "red" | "green" | "unknown";

export interface SignalTiming {
  intersectionId: string;
  phase:          SignalPhase;
  remainingSec:   number;   // seconds remaining in current pedestrian phase
  activeGreenDirs: string[]; // e.g. ["north","south"] — pedestrian green directions
  timestamp:      number;
}

// ─── Raw API shape ────────────────────────────────────────────────────────────

interface V2XPhaseItem {
  itstId?: string;
  ntPdsgStatNm?: string | null;
  etPdsgStatNm?: string | null;
  stPdsgStatNm?: string | null;
  wtPdsgStatNm?: string | null;
  [key: string]: unknown;
}

interface V2XTimingItem {
  itstId?: string;
  ntPdsgRmdrCs?: number | null;
  etPdsgRmdrCs?: number | null;
  stPdsgRmdrCs?: number | null;
  wtPdsgRmdrCs?: number | null;
  [key: string]: unknown;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

const DIR_LABELS: Record<string, string> = {
  nt: "north", et: "east", st: "south", wt: "west",
};
const PDSG_STAT_KEYS = ["ntPdsgStatNm", "etPdsgStatNm", "stPdsgStatNm", "wtPdsgStatNm"] as const;
const PDSG_TIME_KEYS = ["ntPdsgRmdrCs", "etPdsgRmdrCs", "stPdsgRmdrCs", "wtPdsgRmdrCs"] as const;

function isGreen(v: string | null | undefined): boolean {
  return typeof v === "string" && v.toLowerCase().includes("allowed");
}

function isRed(v: string | null | undefined): boolean {
  return typeof v === "string" && v.toLowerCase().includes("stop");
}

function fetchWithTimeout(url: string, ms = 10_000): Promise<Response> {
  const ctrl = new AbortController();
  const tid  = setTimeout(() => ctrl.abort(), ms);
  return fetch(url, { signal: ctrl.signal }).finally(() => clearTimeout(tid));
}

// ─── Merge phase + timing into one SignalTiming record ───────────────────────

function mergeRecord(
  phaseItem: V2XPhaseItem,
  timingItem: V2XTimingItem | undefined,
): SignalTiming {
  const now         = Date.now();
  const itstId      = phaseItem.itstId ?? "";

  // Determine green directions and overall phase
  const greenDirs: string[] = [];
  let anyRed    = false;
  let anyGreen  = false;

  for (const key of PDSG_STAT_KEYS) {
    const val = phaseItem[key];
    const dir = key.slice(0, 2); // "nt", "et", "st", "wt"
    if (isGreen(val)) { greenDirs.push(DIR_LABELS[dir] ?? dir); anyGreen = true; }
    if (isRed(val))   { anyRed = true; }
  }

  const phase: SignalPhase =
    anyGreen ? "green" : anyRed ? "red" : "unknown";

  // Pick remaining time from timing record
  let remainingSec = 0;
  if (timingItem) {
    const rawVals = PDSG_TIME_KEYS
      .map((k) => timingItem[k])
      .filter((v): v is number => typeof v === "number" && v > 0);

    if (rawVals.length > 0) {
      // When GREEN: show longest remaining (most time to cross)
      // When RED:   show shortest remaining (soonest green)
      const raw = phase === "green"
        ? Math.max(...rawVals)
        : Math.min(...rawVals);
      remainingSec = Math.round(raw / 10); // deciseconds → seconds
    }
  }

  return { intersectionId: itstId, phase, remainingSec, activeGreenDirs: greenDirs, timestamp: now };
}

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * getSignalData — fetches phase + timing from both V2X endpoints and merges them.
 *
 * Returns an array of SignalTiming — one per active V2X-equipped intersection
 * in Seoul. The array is sorted: green pedestrian phases first, then red.
 */
export async function getSignalData(): Promise<SignalTiming[]> {
  try {
    const [phaseRes, timingRes] = await Promise.all([
      fetchWithTimeout(PHASE_URL),
      fetchWithTimeout(TIMING_URL),
    ]);

    if (!phaseRes.ok) throw new Error(`Phase API HTTP ${phaseRes.status}`);

    const phaseItems: V2XPhaseItem[]   = await phaseRes.json();
    const timingItems: V2XTimingItem[] = timingRes.ok ? await timingRes.json() : [];

    // Build a timing lookup by itstId
    const timingMap = new Map<string, V2XTimingItem>();
    for (const t of timingItems) {
      if (t.itstId) timingMap.set(t.itstId, t);
    }

    const results = phaseItems.map((p) =>
      mergeRecord(p, p.itstId ? timingMap.get(p.itstId) : undefined)
    );

    // Green pedestrian phases first, then red, then unknown
    return results.sort((a, b) => {
      const rank = { green: 0, red: 1, unknown: 2 } as const;
      return rank[a.phase] - rank[b.phase];
    });

  } catch (err) {
    console.warn("[signalAPI] getSignalData error:", err);
    return [];
  }
}
